# Shortlist

Upload a CV, get matched to live job postings three times a day, and generate an AI-tailored CV for any role in one tap.

## What's in the box

| Path | What it does |
|---|---|
| `public/` | The app (HTML, CSS, JS). CV reading and CV export run in the browser. |
| `netlify/functions/scan.mjs` | `/api/scan` – runs a scan on demand |
| `netlify/functions/profile.mjs` | `/api/profile` – saves settings, returns stored matches |
| `netlify/functions/scheduled-scan.mjs` | Runs at 06:00, 12:00 and 18:00 UTC for every active CV |
| `netlify/edge-functions/ai.js` | `/api/ai` – streams Claude for CV reading and tailoring |
| `netlify/lib/jobs.mjs` | Job board adapters (Adzuna, Reed, Jooble) and match scoring |

Storage uses Netlify Blobs (built in, no setup).

## Deploy

Functions need a build step, so **drag-and-drop deploys won't work**. Use either:

**Netlify CLI**
```bash
npm install -g netlify-cli
cd shortlist
npm install
netlify login
netlify init        # create a new site
netlify deploy --prod
```

**Git**: push this folder to GitHub, then "Add new site → Import from Git" in Netlify. No build command needed; publish directory is `public`.

## Environment variables

Site settings → Environment variables. The app runs in demo mode until you add at least one job source.

| Variable | Needed for | Where to get it |
|---|---|---|
| `ANTHROPIC_API_KEY` | CV reading and tailoring | console.anthropic.com |
| `ANTHROPIC_MODEL` | Optional model override (default `claude-sonnet-5-5`) | |
| `ADZUNA_APP_ID`, `ADZUNA_APP_KEY` | Jobs in 19 countries incl. UK, US, ZA | developer.adzuna.com |
| `REED_API_KEY` | UK jobs from Reed | reed.co.uk/developers |
| `JOOBLE_API_KEY` | Global aggregator (incl. Nigeria, UAE, Ireland, Kenya) | jooble.org/api/about |
| `RESEND_API_KEY` | Optional email alerts | resend.com |
| `ALERT_FROM` | Sender for email alerts, e.g. `Shortlist <alerts@yourdomain.com>` | Verified domain in Resend |

Redeploy after adding variables.

## Notes and limits

- **LinkedIn is not scanned.** LinkedIn has no public job search API and its terms prohibit scraping. Adzuna and Jooble aggregate thousands of boards and many recruiter sites, which covers much of the same market.
- **Scheduled scans** only run on the production deploy.
- **Fit score** is an estimate of how well the CV evidences the ad's requirements. It is not a probability of getting a call.
- **Export** keeps your file type (PDF in, PDF out; Word in, Word out) with a clean, ATS-friendly layout. It does not copy the original file's exact visual design.
- **Browser notifications** work on desktop browsers while the site is open. On phones, use email alerts.
- **Privacy**: CV text stays in the browser. The server stores only target roles, skills, location, alert email and matches. There are no user accounts; each browser gets its own ID. Add Netlify Identity or another auth layer before opening it to other users.
