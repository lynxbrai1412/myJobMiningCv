(() => {
  "use strict";

  // ---------- helpers ----------
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const reEsc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

  const COUNTRIES = [["gb","United Kingdom"],["us","United States"],["ca","Canada"],["au","Australia"],["nz","New Zealand"],["za","South Africa"],["ng","Nigeria"],["ke","Kenya"],["gh","Ghana"],["ae","United Arab Emirates"],["ie","Ireland"],["de","Germany"],["fr","France"],["nl","Netherlands"],["be","Belgium"],["ch","Switzerland"],["at","Austria"],["es","Spain"],["it","Italy"],["pl","Poland"],["in","India"],["sg","Singapore"],["br","Brazil"],["mx","Mexico"]];
  const CURRENCY = { gb: "£", us: "$", ca: "$", au: "$", nz: "$", sg: "$", za: "R", ng: "₦", ke: "KSh ", gh: "GH₵", ae: "AED ", in: "₹", br: "R$", mx: "$", ch: "CHF ", pl: "zł " };
  const countryName = (cc) => (COUNTRIES.find((c) => c[0] === cc) || [, cc.toUpperCase()])[1];

  const KEY = "shortlist.v1";
  const uid = () => (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(16) + Math.random().toString(16).slice(2));
  const blank = () => ({
    id: uid(), view: "matches", cv: null,
    profile: { country: "gb", region: "London", scope: "region", active: false, targetTitles: [], skills: [], minScore: 60, email: "", name: "" },
    matches: [], lastScan: null, demo: false, sources: [], errors: [], tailored: {}, seen: [], notified: [], aiOff: false
  });
  let S;
  try { S = Object.assign(blank(), JSON.parse(localStorage.getItem(KEY)) || {}); } catch { S = blank(); }
  const save = () => {
    try { localStorage.setItem(KEY, JSON.stringify(S)); }
    catch { toast("Browser storage is full. Delete older tailored CVs in Settings."); }
  };

  let toastTimer;
  function toast(msg) {
    const t = $("#toast");
    t.textContent = msg; t.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("show"), 4500);
  }

  async function api(path, body) {
    const res = await fetch(path, body ? { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) } : {});
    let data = {};
    try { data = await res.json(); } catch {}
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
    return data;
  }

  // Streams Claude via the edge function and returns the parsed JSON object.
  async function aiStream(body, onText) {
    const res = await fetch("/api/ai", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    if (!res.ok) {
      let msg = ""; try { msg = (await res.json()).error; } catch {}
      const err = new Error(msg || `AI request failed (${res.status})`); err.status = res.status; throw err;
    }
    const reader = res.body.getReader(); const dec = new TextDecoder();
    let buf = "", out = "", stop = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      let i;
      while ((i = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 1);
        if (!line.startsWith("data:")) continue;
        let ev; try { ev = JSON.parse(line.slice(5)); } catch { continue; }
        if (ev.type === "content_block_delta" && ev.delta?.type === "text_delta") { out += ev.delta.text; onText && onText(out); }
        else if (ev.type === "message_delta" && ev.delta?.stop_reason) stop = ev.delta.stop_reason;
        else if (ev.type === "error") throw new Error(ev.error?.message || "The AI service returned an error. Try again.");
      }
    }
    if (stop === "max_tokens") throw new Error("Your CV is too long for one pass. Shorten it slightly and try again.");
    const clean = out.replace(/```json|```/g, "");
    const a = clean.indexOf("{"), b = clean.lastIndexOf("}");
    if (a < 0 || b < 0) throw new Error("The AI response was incomplete. Try again.");
    return JSON.parse(clean.slice(a, b + 1));
  }

  const ago = (iso) => {
    const s = (Date.now() - Date.parse(iso)) / 1000;
    if (!iso || isNaN(s)) return "";
    if (s < 3600) return `${Math.max(1, Math.round(s / 60))} min ago`;
    if (s < 86400) return `${Math.round(s / 3600)} h ago`;
    const d = Math.round(s / 86400); return `${d} day${d > 1 ? "s" : ""} ago`;
  };
  const money = (j) => {
    if (j.salaryText) return j.salaryText;
    const sym = CURRENCY[S.profile.country] || "";
    const f = (n) => (n >= 1000 ? `${sym}${Math.round(n / 1000)}k` : `${sym}${Math.round(n)}`);
    if (j.salaryMin && j.salaryMax && Math.round(j.salaryMin) !== Math.round(j.salaryMax)) return `${f(j.salaryMin)} to ${f(j.salaryMax)}`;
    return j.salaryMax || j.salaryMin ? f(j.salaryMax || j.salaryMin) : "";
  };
  const ringClass = (v) => (v >= 75 ? "hi" : v >= 50 ? "mid" : "");
  const ring = (v) => `<span class="ring ${ringClass(v)}" style="--v:${v}" data-v="${v}" role="img" aria-label="${v}% match"></span>`;

  // ---------- CV reading ----------
  async function readCv(file) {
    const ext = (file.name.split(".").pop() || "").toLowerCase();
    let text = "";
    if (ext === "pdf") {
      pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
      const pdf = await pdfjsLib.getDocument({ data: await file.arrayBuffer() }).promise;
      const lines = [];
      for (let p = 1; p <= pdf.numPages; p++) {
        const c = await (await pdf.getPage(p)).getTextContent();
        let lastY = null, line = "";
        for (const it of c.items) {
          const y = it.transform[5];
          if (lastY !== null && Math.abs(y - lastY) > 2) { lines.push(line.trim()); line = ""; }
          line += (line && !line.endsWith(" ") && it.str && !it.str.startsWith(" ") ? " " : "") + it.str;
          lastY = y;
        }
        lines.push(line.trim(), "");
      }
      text = lines.join("\n");
    } else if (ext === "docx") {
      text = (await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() })).value;
    } else if (ext === "txt") {
      text = await file.text();
    } else {
      throw new Error("Upload a PDF, DOCX or TXT file.");
    }
    text = text.replace(/\r/g, "").replace(/[ \t]+/g, " ").replace(/\n{3,}/g, "\n\n").trim();
    return { fileName: file.name, ext, text };
  }

  const DICT = ["business analysis","requirements gathering","stakeholder management","process mapping","process improvement","bpmn","agile","scrum","kanban","jira","confluence","sql","python","r","excel","power bi","tableau","data analysis","data modelling","data modeling","uat","user acceptance testing","project management","programme management","change management","risk management","underwriting","claims","reinsurance","lloyd's","london market","insurance","specialty insurance","financial services","banking","payments","compliance","regulatory reporting","aws","azure","gcp","javascript","typescript","react","node.js","java","c#",".net","salesforce","sap","crm","erp","product management","product owner","ux","figma","marketing","seo","sales","business development","account management","customer service","recruitment","payroll","accounting","audit","financial modelling","budgeting","forecasting","operations","supply chain","logistics","procurement","nursing","teaching","safeguarding","healthcare","engineering","autocad","devops","kubernetes","docker","machine learning","cyber security","itil","service management","prince2","pmp","lean","six sigma","reporting","leadership","team management","negotiation","contract management","gdpr","api","integration","testing","test automation","quality assurance","data governance","master data","etl","snowflake","databricks","visio","gap analysis","user stories","workshops","target operating model","digital transformation"];
  function heuristicAnalysis(text) {
    const t = text.toLowerCase();
    const skills = DICT.filter((k) => k.length > 1 && new RegExp(`(^|[^a-z])${reEsc(k)}([^a-z]|$)`).test(t));
    const first = text.split("\n").map((l) => l.trim()).find(Boolean) || "";
    return { name: first.length < 50 ? first : "", skills: skills.slice(0, 25), targetTitles: [] };
  }
  function applyAnalysis(r) {
    const p = S.profile;
    if (r.name) p.name = r.name;
    if (r.targetTitles?.length) p.targetTitles = r.targetTitles.slice(0, 5);
    if (r.skills?.length) p.skills = r.skills.slice(0, 30);
    const cc = String(r.country || "").toLowerCase();
    if (cc && COUNTRIES.some((c) => c[0] === cc)) p.country = cc;
    S.cv.headline = r.headline || "";
  }
  async function analyse() {
    try { applyAnalysis(await aiStream({ task: "analyse", cvText: S.cv.text })); S.aiOff = false; }
    catch (e) {
      applyAnalysis(heuristicAnalysis(S.cv.text));
      if (e.status === 501) S.aiOff = true;
      else toast(`AI reading failed, so we used a basic read. ${e.message}`);
    }
    save();
  }

  async function handleFile(file) {
    if (!file) return;
    if (file.size > 8e6) return toast("That file is over 8 MB. Upload a smaller CV.");
    const dz = $("#dropzone"), status = $("[data-status]", dz);
    const busy = (on, msg) => { dz.classList.toggle("busy", on); dz.disabled = on; status.textContent = msg || "PDF, DOCX or TXT, up to 8 MB"; };
    const onboarding = !S.cv;
    if (!onboarding) toast("Reading your new CV…");
    busy(true, "Reading your CV…");
    try {
      const cv = await readCv(file);
      if (cv.text.length < 200) throw new Error("We couldn't read text from that file. If it's a scanned image, upload a Word file or a text-based PDF.");
      S.cv = cv; S.tailored = {}; save();
      busy(true, "Working out which roles your CV fits…");
      await analyse();
      show("cv");
      toast(S.profile.targetTitles.length ? "CV read. Check your target roles, then save and scan." : "CV read. Add the job titles you're targeting, then save and scan.");
    } catch (e) { toast(e.message); }
    finally { busy(false); $("#cvFile").value = ""; }
  }

  // ---------- views ----------
  function show(view) {
    if (!S.cv) view = "onboard";
    $$(".view").forEach((v) => (v.hidden = v.id !== `view-${view}`));
    $$(".tabs button").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.tab === view)));
    $(".tabs").hidden = !S.cv; $("#bellBtn").hidden = !S.cv;
    if (view !== "onboard") S.view = view;
    save();
    if (view === "matches") renderMatches();
    if (view === "cv") renderCvTab();
    if (view === "settings") renderSettings();
    window.scrollTo({ top: 0 });
  }

  const freshHits = () => S.matches.filter((j) => j.isNew && !S.seen.includes(j.key) && j.score >= S.profile.minScore);

  function renderMatches() {
    const p = S.profile;
    const where = p.scope === "country" ? countryName(p.country) : [p.region, countryName(p.country)].filter(Boolean).join(", ");
    $("#matchSub").textContent = `${where}${S.lastScan ? `. Last scanned ${ago(S.lastScan)}` : ""}${p.active ? "" : ". Automatic scanning is off"}`;

    const notes = [];
    if (S.demo) notes.push(`<div class="notice">These are sample postings so you can try the app. Add job board API keys in Netlify to see live roles.</div>`);
    if (S.errors?.length) notes.push(`<div class="notice err">Some job sources didn't respond on the last scan: ${esc(S.errors.join("; "))}</div>`);
    $("#matchNotice").innerHTML = notes.join("");

    const min = Number($("#minFilter").value);
    const jobs = S.matches.filter((j) => j.score >= min);
    const list = $("#matchList");
    if (!S.matches.length) {
      list.className = "";
      list.innerHTML = `<div class="empty"><h3>No matches yet</h3><p class="sub">Run a scan to find roles that fit your CV.</p><button class="btn primary" data-act="scan">Scan now</button></div>`;
      return;
    }
    if (!jobs.length) {
      list.className = "";
      list.innerHTML = `<div class="empty"><h3>No matches at ${min}% or above</h3><p class="sub">Lower the minimum match, or add more skills on the My CV tab.</p></div>`;
      return;
    }
    list.className = "job-list";
    list.innerHTML = jobs.map(jobRow).join("");
  }

  function jobRow(j) {
    const isFresh = j.isNew && !S.seen.includes(j.key);
    const meta = [j.location, money(j), ago(j.posted), j.source].filter(Boolean).join(", ");
    return `<button class="job" data-key="${esc(j.key)}">
      ${ring(j.score)}
      <span class="job-main"><strong>${esc(j.title)}</strong><span class="job-co">${esc(j.company || "Company not listed")}</span><span class="job-meta">${esc(meta)}</span></span>
      <span class="job-side">${isFresh ? `<span class="new">New</span>` : S.tailored[j.key] ? `<span class="tailored-flag">CV tailored</span>` : ""}</span>
    </button>`;
  }

  function chipEditor(el, key, placeholder) {
    const draw = () => {
      const list = S.profile[key];
      el.innerHTML = list.map((v, i) => `<span class="chip">${esc(v)}<button type="button" data-i="${i}" aria-label="Remove ${esc(v)}">×</button></span>`).join("") +
        `<input type="text" placeholder="${esc(placeholder)}" aria-label="${esc(placeholder)}">`;
      const input = $("input", el);
      const add = () => {
        const vals = input.value.split(",").map((s) => s.trim()).filter(Boolean);
        if (!vals.length) return;
        for (const v of vals) if (!list.some((x) => x.toLowerCase() === v.toLowerCase())) list.push(v);
        save(); draw(); $("input", el).focus();
      };
      input.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === ",") { e.preventDefault(); add(); }
        else if (e.key === "Backspace" && !input.value && list.length) { list.pop(); save(); draw(); $("input", el).focus(); }
      });
      input.addEventListener("blur", add);
      $$(".chip button", el).forEach((b) => b.addEventListener("click", () => { list.splice(Number(b.dataset.i), 1); save(); draw(); }));
    };
    draw();
  }

  function renderCvTab() {
    const p = S.profile;
    $("#cvMeta").textContent = `${S.cv.fileName}, ${S.cv.text.split(/\s+/).length.toLocaleString()} words${S.aiOff ? ". AI is not set up yet, so roles and skills came from a basic read" : ""}`;
    $("#cvRaw").textContent = S.cv.text;
    $("#activeToggle").checked = p.active;
    $("#countrySel").value = p.country;
    $("#regionInput").value = p.region;
    $$('input[name="scope"]').forEach((r) => (r.checked = r.value === p.scope));
    chipEditor($("#titlesEditor"), "targetTitles", "Add a job title");
    chipEditor($("#skillsEditor"), "skills", "Add a skill");
  }

  function renderSettings() {
    $("#alertMin").value = String(S.profile.minScore);
    $("#emailInput").value = S.profile.email || "";
    const st = !("Notification" in window) ? "unsupported" : Notification.permission;
    $("#notifState").textContent = {
      granted: "On. You'll get an alert while Shortlist is open or in a background tab.",
      denied: "Blocked. Allow notifications for this site in your browser settings.",
      default: "Off.",
      unsupported: "This browser doesn't support notifications. Use email alerts instead."
    }[st];
    $("#notifBtn").hidden = st !== "default";
  }

  // ---------- scanning, polling, alerts ----------
  const serverProfile = () => ({ id: S.id, ...S.profile });

  function applyMatches(m, { quiet } = {}) {
    S.matches = m.jobs || []; S.lastScan = m.lastScan || S.lastScan;
    S.demo = !!m.demo; S.sources = m.sources || []; S.errors = m.errors || [];
    const fresh = freshHits().filter((j) => !S.notified.includes(j.key));
    if (fresh.length) {
      S.notified = [...S.notified, ...fresh.map((j) => j.key)].slice(-1500);
      if (!quiet) notify(fresh);
    }
    save(); updateBell();
    if (S.view === "matches" && !$("#view-matches").hidden) renderMatches();
  }

  let scanning = false;
  async function scanNow() {
    if (scanning) return;
    if (!S.profile.targetTitles.length && !S.profile.skills.length) { show("cv"); return toast("Add at least one target role or skill first."); }
    scanning = true; $("#scanbar").classList.add("on"); $$("#scanBtn, [data-act=scan], #saveCv").forEach((b) => (b.disabled = true));
    try {
      const r = await api("/api/scan", { profile: serverProfile() });
      applyMatches(r, { quiet: true });
      const fresh = freshHits().length;
      toast(fresh ? `${fresh} new match${fresh > 1 ? "es" : ""} at ${S.profile.minScore}% or above.` : "Scan finished. No new matches above your alert threshold.");
    } catch (e) { toast(e.message); }
    finally { scanning = false; $("#scanbar").classList.remove("on"); $$("#scanBtn, [data-act=scan], #saveCv").forEach((b) => (b.disabled = false)); }
  }

  async function poll() {
    if (!S.cv || scanning) return;
    try { const r = await api(`/api/profile?id=${encodeURIComponent(S.id)}`); if (r.matches) applyMatches(r.matches); } catch {}
  }

  function notify(jobs) {
    $("#bellBtn").classList.remove("ring-anim"); void $("#bellBtn").offsetWidth; $("#bellBtn").classList.add("ring-anim");
    if (!("Notification" in window) || Notification.permission !== "granted") return;
    try {
      const n = new Notification(`${jobs.length} new CV match${jobs.length > 1 ? "es" : ""}`, {
        body: jobs.slice(0, 3).map((j) => `${j.score}%: ${j.title}, ${j.company}`).join("\n"), tag: "shortlist"
      });
      n.onclick = () => { window.focus(); show("matches"); n.close(); };
    } catch {}
  }

  function updateBell() {
    const n = freshHits().length, b = $("#bellBadge");
    b.hidden = !n; b.textContent = n > 99 ? "99+" : String(n);
    $("#bellBtn").setAttribute("aria-label", n ? `${n} new matches` : "No new matches");
    if (!$("#alertsPanel").hidden) renderAlerts();
  }
  function renderAlerts() {
    const fresh = freshHits().slice(0, 30);
    $("#alertsList").innerHTML = fresh.length ? fresh.map(jobRow).join("") : `<p class="empty-small">You're up to date. New matches above ${S.profile.minScore}% will show here.</p>`;
  }

  // ---------- job detail and tailoring ----------
  let openKey = null;
  function openJob(key) {
    const j = S.matches.find((x) => x.key === key);
    if (!j) return;
    openKey = key;
    if (!S.seen.includes(key)) { S.seen = [...S.seen, key].slice(-1500); save(); updateBell(); }
    $("#alertsPanel").hidden = true;
    renderDetail(j);
    const d = $("#detail");
    d.hidden = false; $("#scrim").hidden = false; d.scrollTop = 0;
    requestAnimationFrame(() => d.classList.add("open"));
    $(".d-close", d).focus();
    if (!$("#view-matches").hidden) renderMatches();
  }
  function closeJob() {
    const d = $("#detail");
    d.classList.remove("open"); $("#scrim").hidden = true; openKey = null;
    setTimeout(() => { if (!openKey) d.hidden = true; }, 330);
  }

  function renderDetail(j) {
    const skills = S.profile.skills;
    const hit = new Set((j.matchedSkills || []).map((s) => s.toLowerCase()));
    const meta = [j.location, money(j), j.posted ? `posted ${ago(j.posted)}` : "", j.source].filter(Boolean).join(", ");
    const t = S.tailored[j.key];
    $("#detailInner").innerHTML = `
      <div class="d-top"><button class="btn d-close" data-act="close">Close</button></div>
      <div class="d-head">${ring(j.score)}<div><h2>${esc(j.title)}</h2><p>${esc(j.company || "Company not listed")}</p><p>${esc(meta)}</p></div></div>
      <div class="d-actions">${j.url ? `<a class="btn" href="${esc(j.url)}" target="_blank" rel="noopener">Open the job ad</a>` : ""}</div>
      <div class="d-section"><h3>Your skills against this ad</h3>
        <div class="kw">${skills.map((s) => `<span class="${hit.has(s.toLowerCase()) ? "hit" : ""}">${esc(s)}</span>`).join("") || `<span>No skills listed yet</span>`}</div>
        <p class="sub">Highlighted skills appear in the ad text we received.</p></div>
      <div class="d-section"><h3>From the ad</h3><p class="desc">${esc(j.description || "No description provided.")}</p>
        <details><summary>Paste the full job description for a sharper rewrite</summary>
        <textarea id="jdInput" placeholder="Job boards often share only a snippet. Paste the full ad here.">${esc(t?.jdUsed || "")}</textarea></details></div>
      <div id="tailorZone">${t ? "" : tailorCta()}</div>`;
    if (t) renderTailored(j, t, false);
  }

  const tailorCta = () => `<div class="tailor-cta">
      <strong>Rewrite your CV for this role</strong>
      <p>We reorder and reword what's already in your CV to match this ad. Nothing is invented, and anything you're missing is listed separately.</p>
      <button class="btn accent" data-act="tailor">Tailor my CV</button></div>`;

  async function tailor(j) {
    const zone = $("#tailorZone");
    const jd = ($("#jdInput")?.value || "").trim();
    zone.innerHTML = `<div class="stream"><div class="stream-status"><strong id="streamStage">Reading the job ad</strong><span id="streamCount"></span></div>
      <div class="paper ghost-paper" aria-hidden="true">${"<i></i>".repeat(14)}</div></div>`;
    zone.scrollIntoView({ behavior: "smooth", block: "start" });
    let r;
    try {
      r = await aiStream({ task: "tailor", cvText: S.cv.text, job: { title: j.title, company: j.company, location: j.location, description: jd || j.description } }, (txt) => {
        const heads = [...txt.matchAll(/"heading"\s*:\s*"([^"]+)"/g)];
        const stage = txt.includes('"recruiterNote"') ? "Writing your note to the recruiter"
          : txt.includes('"gaps"') ? "Checking what the ad asks for that your CV doesn't show"
          : txt.includes('"matchedKeywords"') ? "Matching keywords"
          : heads.length ? `Rewriting ${heads[heads.length - 1][1]}`
          : txt.includes('"skills"') ? "Reordering your skills"
          : txt.includes('"summary"') ? "Rewriting your profile" : "Reading the job ad";
        const s = $("#streamStage"); if (s) s.textContent = stage;
        const c = $("#streamCount"); if (c) c.textContent = `${txt.length.toLocaleString()} characters`;
      });
    } catch (e) {
      if (e.status === 501) {
        r = heuristicTailor(j);
        toast("AI isn't set up, so this is a basic keyword reorder. Add ANTHROPIC_API_KEY for full rewrites.");
      } else {
        if (openKey === j.key) { zone.innerHTML = tailorCta(); }
        return toast(e.message);
      }
    }
    if (!r?.tailoredCv) { if (openKey === j.key) zone.innerHTML = tailorCta(); return toast("The rewrite came back incomplete. Try again."); }
    r.jdUsed = jd; r.at = new Date().toISOString();
    S.tailored[j.key] = r; save();
    if (openKey === j.key) renderTailored(j, r, true);
    if (!$("#view-matches").hidden) renderMatches();
  }

  function heuristicTailor(j) {
    const lines = S.cv.text.split("\n").map((l) => l.trim());
    const jt = `${j.title} ${j.description}`.toLowerCase();
    const matched = S.profile.skills.filter((s) => jt.includes(s.toLowerCase()));
    return {
      tailoredCv: {
        name: S.profile.name || lines.find(Boolean) || "", contact: "", headline: S.cv.headline || "",
        summary: "", skills: [...matched, ...S.profile.skills.filter((s) => !matched.includes(s))],
        sections: [{ heading: "Experience and background", text: lines.slice(1).join("\n").trim() }]
      },
      matchedKeywords: matched, gaps: [], changes: ["Moved the skills this ad mentions to the top of your skills list."],
      fitBefore: j.score, fitAfter: j.score, recruiterNote: "", basic: true
    };
  }

  function highlighter(kws) {
    const terms = (kws || []).filter((k) => k && k.length > 1).sort((a, b) => b.length - a.length).map((k) => reEsc(esc(k)));
    if (!terms.length) return esc;
    const re = new RegExp(`(${terms.join("|")})`, "gi");
    let n = 0;
    return (t) => esc(t).replace(re, (m) => `<mark style="--d:${(n++ % 30) * 60 + 300}ms">${m}</mark>`);
  }

  function cvHtml(cv, kws) {
    const hl = highlighter(kws);
    const sections = (cv.sections || []).map((s) => `<section><h4>${esc(s.heading)}</h4>
      ${(s.items || []).map((it) => `<div class="cv-item">
        <div class="cv-item-head"><strong>${hl(it.title)}</strong>${it.dates ? `<span>${esc(it.dates)}</span>` : ""}</div>
        ${it.subtitle ? `<em>${hl(it.subtitle)}</em>` : ""}
        ${(it.bullets || []).length ? `<ul>${it.bullets.map((b) => `<li>${hl(b)}</li>`).join("")}</ul>` : ""}
      </div>`).join("")}
      ${s.text ? `<p class="pre">${hl(s.text)}</p>` : ""}</section>`).join("");
    return `<div class="cv-name">${esc(cv.name)}</div>
      ${cv.contact ? `<p class="cv-contact">${esc(cv.contact)}</p>` : ""}
      ${cv.headline ? `<p class="cv-headline">${hl(cv.headline)}</p>` : ""}
      ${cv.summary ? `<section><h4>Profile</h4><p>${hl(cv.summary)}</p></section>` : ""}
      ${(cv.skills || []).length ? `<section><h4>Key skills</h4><p>${cv.skills.map(hl).join(", ")}</p></section>` : ""}
      ${sections}`;
  }

  function renderTailored(j, r, animate) {
    const zone = $("#tailorZone");
    const ext = S.cv.ext;
    const before = Math.round(r.fitBefore ?? j.score), after = Math.round(r.fitAfter ?? j.score);
    zone.innerHTML = `
      <div class="fit">
        <div class="fit-row"><span>Original CV</span><div class="fit-bar"><b data-w="${before}"></b></div><strong>${before}</strong></div>
        <div class="fit-row after"><span>Tailored CV</span><div class="fit-bar"><b data-w="${after}"></b></div><strong>${after}</strong></div>
        <p class="fit-note">How well each version evidences the ad's stated requirements, out of 100. ${r.basic ? "AI isn't set up, so this score hasn't changed." : "This measures fit, not the odds of a call."}</p>
      </div>
      <article class="paper ${animate ? "reveal" : ""}">${cvHtml(r.tailoredCv, r.matchedKeywords)}</article>
      <div class="lists">
        <div><h3>What changed</h3><ul>${(r.changes || []).map((c) => `<li>${esc(c)}</li>`).join("") || "<li>No changes listed.</li>"}</ul></div>
        <div><h3>Gaps to cover in your message or interview</h3><ul>${(r.gaps || []).map((c) => `<li>${esc(c)}</li>`).join("") || "<li>None found against this ad.</li>"}</ul></div>
      </div>
      ${r.recruiterNote ? `<div class="note-box"><h3>Message to the recruiter</h3><p>${esc(r.recruiterNote)}</p><button class="btn" data-act="copy-note">Copy message</button></div>` : ""}
      <div class="export-bar">
        <button class="btn primary" data-act="export">Download tailored CV (.${esc(ext)})</button>
        ${ext !== "docx" ? `<button class="btn" data-act="export-docx">Download as Word</button>` : ""}
        <button class="btn" data-act="retailor">Tailor again</button>
        ${j.url ? `<a class="btn" href="${esc(j.url)}" target="_blank" rel="noopener">Apply on ${esc(j.source)}</a>` : ""}
      </div>`;
    requestAnimationFrame(() => requestAnimationFrame(() => $$(".fit-bar b", zone).forEach((b) => (b.style.width = `${b.dataset.w}%`))));
  }

  // ---------- export ----------
  function cvBlocks(cv) {
    const b = [];
    if (cv.name) b.push({ t: "name", x: cv.name });
    if (cv.contact) b.push({ t: "contact", x: cv.contact });
    if (cv.headline) b.push({ t: "headline", x: cv.headline });
    if (cv.summary) { b.push({ t: "h", x: "Profile" }); b.push({ t: "p", x: cv.summary }); }
    if (cv.skills?.length) { b.push({ t: "h", x: "Key skills" }); b.push({ t: "p", x: cv.skills.join(", ") }); }
    for (const s of cv.sections || []) {
      b.push({ t: "h", x: s.heading || "" });
      for (const it of s.items || []) {
        b.push({ t: "item", x: it.title || "", d: it.dates || "" });
        if (it.subtitle) b.push({ t: "sub", x: it.subtitle });
        for (const bl of it.bullets || []) b.push({ t: "bullet", x: bl });
      }
      if (s.text) s.text.split("\n").filter((l) => l.trim()).forEach((l) => b.push({ t: "p", x: l }));
    }
    return b;
  }
  const slug = (s) => String(s || "").replace(/[^a-z0-9]+/gi, "_").replace(/^_|_$/g, "").slice(0, 40) || "CV";
  function download(blob, name) {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  // Standard PDF fonts only cover Latin-1 plus a few symbols, so normalise the rest.
  const pdfSafe = (s) => String(s).replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"').replace(/[\u2013\u2014]/g, "-").replace(/\u2026/g, "...").replace(/[^\x00-\xFF•]/g, "");

  function exportPdf(cv, name) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const W = 595.28, H = 841.89, M = 54; let y = M;
    const ink = [20, 27, 45], slate = [90, 98, 117], cobalt = [35, 70, 216];
    const ensure = (h) => { if (y + h > H - M) { doc.addPage(); y = M; } };
    const write = (text, { size = 10.5, style = "normal", color = ink, indent = 0, after = 4, font = "helvetica", width } = {}) => {
      doc.setFont(font, style); doc.setFontSize(size); doc.setTextColor(...color);
      const lh = size * 1.38;
      for (const l of doc.splitTextToSize(pdfSafe(text), width || W - 2 * M - indent)) { ensure(lh); doc.text(l, M + indent, y + size); y += lh; }
      y += after;
    };
    for (const b of cvBlocks(cv)) {
      if (b.t === "name") write(b.x, { size: 22, style: "bold", font: "times", after: 2 });
      else if (b.t === "contact") write(b.x, { size: 9.5, color: slate, after: 4 });
      else if (b.t === "headline") write(b.x, { size: 11.5, style: "italic", font: "times", after: 6 });
      else if (b.t === "h") {
        ensure(40); y += 10; write(b.x, { size: 10.5, style: "bold", color: cobalt, after: 0 });
        doc.setDrawColor(218, 221, 228); doc.setLineWidth(0.7); doc.line(M, y + 2, W - M, y + 2); y += 9;
      } else if (b.t === "item") {
        ensure(30); y += 3;
        if (b.d) { doc.setFont("helvetica", "normal"); doc.setFontSize(9.5); doc.setTextColor(...slate); doc.text(pdfSafe(b.d), W - M, y + 10.5, { align: "right" }); }
        const dw = b.d ? doc.getTextWidth(pdfSafe(b.d)) + 14 : 0;
        write(b.x, { size: 10.5, style: "bold", after: 1, width: W - 2 * M - dw });
      } else if (b.t === "sub") write(b.x, { size: 10, style: "italic", color: slate, after: 3 });
      else if (b.t === "bullet") {
        doc.setFont("helvetica", "normal"); doc.setFontSize(10.5); doc.setTextColor(...ink);
        ensure(15); doc.text("•", M + 4, y + 10.5);
        write(b.x, { indent: 16, after: 2 });
      } else write(b.x, { after: 4 });
    }
    download(doc.output("blob"), name);
  }

  async function exportDocx(cv, name) {
    const x = (s) => esc(s).replace(/&#39;/g, "&apos;");
    const run = (t, { b, i, sz = 21, color } = {}) =>
      `<w:r><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/>${b ? "<w:b/>" : ""}${i ? "<w:i/>" : ""}${color ? `<w:color w:val="${color}"/>` : ""}<w:sz w:val="${sz}"/></w:rPr><w:t xml:space="preserve">${x(t)}</w:t></w:r>`;
    const para = (runs, { after = 80, before = 0, border, tabs, ind } = {}) =>
      `<w:p><w:pPr>${border ? `<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="2" w:color="DADDE4"/></w:pBdr>` : ""}${tabs ? `<w:tabs><w:tab w:val="right" w:pos="9900"/></w:tabs>` : ""}<w:spacing w:before="${before}" w:after="${after}"/>${ind ? `<w:ind w:left="360" w:hanging="220"/>` : ""}</w:pPr>${runs}</w:p>`;
    const body = cvBlocks(cv).map((b) => {
      switch (b.t) {
        case "name": return para(run(b.x, { b: true, sz: 40 }), { after: 40 });
        case "contact": return para(run(b.x, { sz: 18, color: "5A6275" }), { after: 80 });
        case "headline": return para(run(b.x, { i: true, sz: 23 }), { after: 120 });
        case "h": return para(run(b.x, { b: true, sz: 21, color: "2346D8" }), { before: 240, after: 100, border: true });
        case "item": return para(run(b.x, { b: true }) + (b.d ? `<w:r><w:tab/></w:r>${run(b.d, { sz: 19, color: "5A6275" })}` : ""), { before: 80, after: 20, tabs: true });
        case "sub": return para(run(b.x, { i: true, sz: 20, color: "5A6275" }), { after: 60 });
        case "bullet": return para(run("•\u00A0\u00A0" + b.x), { after: 40, ind: true });
        default: return para(run(b.x), { after: 80 });
      }
    }).join("");
    const zip = new JSZip();
    zip.file("[Content_Types].xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>`);
    zip.file("_rels/.rels", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`);
    zip.file("word/document.xml", `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${body}<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1000" w:right="1000" w:bottom="1000" w:left="1000" w:header="500" w:footer="500" w:gutter="0"/></w:sectPr></w:body></w:document>`);
    download(await zip.generateAsync({ type: "blob", mimeType: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" }), name);
  }

  function exportTxt(cv, name) {
    const out = cvBlocks(cv).map((b) => {
      if (b.t === "h") return `\n${b.x.toUpperCase()}\n${"-".repeat(b.x.length)}`;
      if (b.t === "item") return `\n${b.x}${b.d ? `    ${b.d}` : ""}`;
      if (b.t === "bullet") return `  • ${b.x}`;
      return b.x;
    }).join("\n");
    download(new Blob([out.trim() + "\n"], { type: "text/plain;charset=utf-8" }), name);
  }

  async function exportCv(j, forceExt) {
    const r = S.tailored[j.key]; if (!r) return;
    const ext = forceExt || S.cv.ext;
    const name = `${slug(r.tailoredCv.name || S.profile.name)}_CV_${slug(j.company || j.title)}.${ext}`;
    try {
      if (ext === "pdf") exportPdf(r.tailoredCv, name);
      else if (ext === "docx") await exportDocx(r.tailoredCv, name);
      else exportTxt(r.tailoredCv, name);
      toast(`Downloaded ${name}`);
    } catch (e) { toast(`Download failed: ${e.message}`); }
  }

  // ---------- events ----------
  function bind() {
    const sel = $("#countrySel");
    sel.innerHTML = COUNTRIES.map(([c, n]) => `<option value="${c}">${esc(n)}</option>`).join("");

    $$("[data-tab]").forEach((b) => b.addEventListener("click", (e) => { e.preventDefault(); show(b.dataset.tab); }));

    const dz = $("#dropzone");
    dz.addEventListener("click", () => $("#cvFile").click());
    ["dragenter", "dragover"].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.add("over"); }));
    ["dragleave", "drop"].forEach((ev) => dz.addEventListener(ev, (e) => { e.preventDefault(); dz.classList.remove("over"); }));
    dz.addEventListener("drop", (e) => handleFile(e.dataTransfer.files[0]));
    $("#cvFile").addEventListener("change", (e) => handleFile(e.target.files[0]));
    $("#replaceCv").addEventListener("click", () => $("#cvFile").click());

    $("#minFilter").value = String(S.minFilter ?? 60);
    $("#minFilter").addEventListener("change", (e) => { S.minFilter = Number(e.target.value); save(); renderMatches(); });
    $("#scanBtn").addEventListener("click", scanNow);

    $("#countrySel").addEventListener("change", (e) => { S.profile.country = e.target.value; save(); });
    $("#regionInput").addEventListener("input", (e) => { S.profile.region = e.target.value.trim(); save(); });
    $$('input[name="scope"]').forEach((r) => r.addEventListener("change", () => { S.profile.scope = r.value; save(); }));
    $("#activeToggle").addEventListener("change", async (e) => {
      S.profile.active = e.target.checked; save();
      try { await api("/api/profile", { action: "save", profile: serverProfile() }); toast(S.profile.active ? "Automatic scanning is on." : "Automatic scanning is off."); }
      catch (err) { toast(err.message); }
    });
    $("#saveCv").addEventListener("click", async () => { await scanNow(); if (S.matches.length) show("matches"); });

    $("#alertMin").addEventListener("change", (e) => { S.profile.minScore = Number(e.target.value); save(); updateBell(); });
    $("#saveSettings").addEventListener("click", async () => {
      S.profile.email = $("#emailInput").value.trim(); save();
      try { await api("/api/profile", { action: "save", profile: serverProfile() }); toast("Alert settings saved."); } catch (e) { toast(e.message); }
    });
    $("#notifBtn").addEventListener("click", async () => {
      try { await Notification.requestPermission(); } catch {}
      renderSettings();
      if (Notification.permission === "granted") toast("Browser notifications are on.");
    });
    $("#clearTailored").addEventListener("click", () => { if (confirm("Delete all tailored CVs from this browser?")) { S.tailored = {}; save(); toast("Tailored CVs deleted."); } });
    $("#resetAll").addEventListener("click", async () => {
      if (!confirm("Delete your CV, matches and settings from this browser and stop scanning?")) return;
      try { await api("/api/profile", { action: "save", profile: { ...serverProfile(), active: false, targetTitles: [], skills: [], email: "" } }); } catch {}
      localStorage.removeItem(KEY); S = blank(); save(); closeJob(); show("onboard"); toast("Everything was deleted.");
    });

    $("#bellBtn").addEventListener("click", (e) => {
      e.stopPropagation();
      const p = $("#alertsPanel"); p.hidden = !p.hidden;
      if (!p.hidden) renderAlerts();
    });
    $("#markSeen").addEventListener("click", () => {
      S.seen = [...new Set([...S.seen, ...freshHits().map((j) => j.key)])].slice(-1500); save(); updateBell();
      api("/api/profile", { action: "seen", id: S.id }).catch(() => {});
      if (!$("#view-matches").hidden) renderMatches();
    });
    document.addEventListener("click", (e) => {
      const p = $("#alertsPanel");
      if (!p.hidden && !p.contains(e.target) && !e.target.closest("#bellBtn")) p.hidden = true;
    });

    // Delegated clicks for rendered content
    document.addEventListener("click", (e) => {
      const job = e.target.closest(".job[data-key]");
      if (job) return openJob(job.dataset.key);
      const act = e.target.closest("[data-act]")?.dataset.act;
      if (!act) return;
      const j = S.matches.find((x) => x.key === openKey);
      if (act === "scan") scanNow();
      else if (act === "close") closeJob();
      else if (!j) return;
      else if (act === "tailor" || act === "retailor") tailor(j);
      else if (act === "export") exportCv(j);
      else if (act === "export-docx") exportCv(j, "docx");
      else if (act === "copy-note") navigator.clipboard?.writeText(S.tailored[j.key]?.recruiterNote || "").then(() => toast("Message copied."), () => toast("Copy failed. Select the text instead."));
    });
    $("#scrim").addEventListener("click", closeJob);
    document.addEventListener("keydown", (e) => { if (e.key === "Escape") { if (openKey) closeJob(); $("#alertsPanel").hidden = true; } });
    document.addEventListener("visibilitychange", () => { if (!document.hidden) poll(); });
  }

  bind();
  updateBell();
  show(S.cv ? S.view || "matches" : "onboard");
  poll();
  setInterval(poll, 5 * 60 * 1000);
})();
