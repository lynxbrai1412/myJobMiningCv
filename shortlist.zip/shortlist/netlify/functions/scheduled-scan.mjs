// Runs three times a day on published (production) deploys.
import { store, runScan, notifyEmail } from "../lib/core.mjs";

export default async () => {
  const s = store();
  const { blobs } = await s.list({ prefix: "profiles/" });
  for (const b of blobs) {
    const p = await s.get(b.key, { type: "json" });
    if (!p?.active) continue;
    try {
      const { fresh } = await runScan(s, p);
      await notifyEmail(p, fresh);
    } catch (e) {
      console.error(`Scan failed for ${p.id}`, e);
    }
  }
};

export const config = { schedule: "0 6,12,18 * * *" };
