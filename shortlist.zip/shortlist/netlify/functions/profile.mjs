import { store, json, cleanProfile } from "../lib/core.mjs";

export default async (req) => {
  const s = store();
  if (req.method === "GET") {
    const id = new URL(req.url).searchParams.get("id");
    if (!id) return json({ error: "Missing id" }, 400);
    const [profile, matches] = await Promise.all([
      s.get(`profiles/${id}`, { type: "json" }),
      s.get(`matches/${id}`, { type: "json" })
    ]);
    return json({ profile, matches });
  }
  if (req.method === "POST") {
    const body = await req.json().catch(() => ({}));
    if (body.action === "save") {
      const p = cleanProfile(body.profile);
      if (!p.id) return json({ error: "Missing profile id" }, 400);
      await s.setJSON(`profiles/${p.id}`, p);
      return json({ profile: p });
    }
    if (body.action === "seen" && body.id) {
      const m = await s.get(`matches/${body.id}`, { type: "json" });
      if (m) { m.newCount = 0; await s.setJSON(`matches/${body.id}`, m); }
      return json({ ok: true });
    }
    return json({ error: "Unknown action" }, 400);
  }
  return json({ error: "Method not allowed" }, 405);
};

export const config = { path: "/api/profile" };
