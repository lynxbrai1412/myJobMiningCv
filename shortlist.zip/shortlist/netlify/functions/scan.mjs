import { store, json, cleanProfile, runScan } from "../lib/core.mjs";

export default async (req) => {
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);
  const body = await req.json().catch(() => ({}));
  const p = cleanProfile(body.profile);
  if (!p.id) return json({ error: "Missing profile id" }, 400);
  if (!p.targetTitles.length && !p.skills.length) {
    return json({ error: "Add at least one target role or skill on the My CV tab, then scan again." }, 400);
  }
  const s = store();
  await s.setJSON(`profiles/${p.id}`, p);
  const { record } = await runScan(s, p);
  return json(record);
};

export const config = { path: "/api/scan" };
