// Streams Claude's response straight through to the browser.
// Runs as an Edge Function so long rewrites don't hit the 10s serverless timeout.

const ANALYSE_SYSTEM = `You read CVs the way an experienced recruiter does. Return ONLY a JSON object, no markdown, with this shape:
{"name": "candidate's full name", "headline": "one-line professional headline taken from the CV", "targetTitles": ["3 to 5 job titles this person is realistically competitive for today, most likely first, written as they appear on job boards"], "skills": ["15 to 25 concise skills, tools, methods and domains the CV evidences, phrased the way recruiters search for them"], "seniority": "entry | mid | senior | lead | executive", "country": "two-letter ISO country code if clearly stated, otherwise empty string"}`;

const TAILOR_SYSTEM = `You are a senior recruiter and CV writer. Rewrite the candidate's CV so it targets one specific job as strongly as the truth allows.

Hard rules:
1. Use only facts in the original CV. Never invent employers, job titles, dates, qualifications, certifications, tools, metrics or achievements.
2. You may reorder, re-emphasise, rephrase, merge and trim. Where the CV clearly shows a skill under a different name, use the job ad's terminology for it.
3. If the job asks for something the CV does not evidence, put it in "gaps" as practical advice. Do not add it to the CV.
4. Keep the candidate's spelling convention (British or American). Write concise, achievement-led bullets that start with strong verbs. Keep every number exactly as given.
5. Put the most relevant experience and skills first. Keep the CV no longer than the original.
6. Keep every role from the original CV with its real dates; older or less relevant roles can be shortened to one or two bullets.

Return ONLY a JSON object, no markdown, with this shape:
{
  "tailoredCv": {
    "name": "", "contact": "contact details on one line, exactly as in the original",
    "headline": "", "summary": "3-4 sentence profile aimed at this job",
    "skills": ["most relevant first"],
    "sections": [ { "heading": "e.g. Experience, Education, Certifications", "items": [ { "title": "role or qualification", "subtitle": "employer or institution, location", "dates": "", "bullets": [""] } ] } ]
  },
  "matchedKeywords": ["terms from the job ad that the tailored CV now truthfully reflects"],
  "gaps": ["requirements the CV doesn't evidence, phrased as advice"],
  "changes": ["each significant change, one short sentence"],
  "fitBefore": 0, "fitAfter": 0,
  "recruiterNote": "a 3-4 sentence message the candidate can send to the recruiter about this role"
}
fitBefore and fitAfter are your honest 0-100 estimates of how well the original and tailored CV evidence this job's stated requirements. They are not probabilities of getting a call.`;

export default async (req) => {
  if (req.method !== "POST") return Response.json({ error: "Method not allowed" }, { status: 405 });
  const key = Netlify.env.get("ANTHROPIC_API_KEY");
  if (!key) {
    return Response.json({ error: "AI is not set up. Add ANTHROPIC_API_KEY in your Netlify environment variables." }, { status: 501 });
  }

  let body;
  try { body = await req.json(); } catch { return Response.json({ error: "Invalid request" }, { status: 400 }); }
  const cv = String(body.cvText || "").slice(0, 20000);
  if (cv.length < 100) return Response.json({ error: "CV text is missing or too short." }, { status: 400 });

  let system, user, max_tokens;
  if (body.task === "analyse") {
    system = ANALYSE_SYSTEM;
    user = `CV:\n"""\n${cv}\n"""`;
    max_tokens = 1500;
  } else if (body.task === "tailor") {
    const j = body.job || {};
    system = TAILOR_SYSTEM;
    user = `JOB\nTitle: ${String(j.title || "").slice(0, 200)}\nCompany: ${String(j.company || "").slice(0, 200)}\nLocation: ${String(j.location || "").slice(0, 200)}\nDescription:\n"""\n${String(j.description || "").slice(0, 12000)}\n"""\n\nORIGINAL CV\n"""\n${cv}\n"""`;
    max_tokens = 8000;
  } else {
    return Response.json({ error: "Unknown task" }, { status: 400 });
  }

  const upstream = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json" },
    body: JSON.stringify({
      model: Netlify.env.get("ANTHROPIC_MODEL") || "claude-sonnet-5-5",
      max_tokens, stream: true, system,
      messages: [{ role: "user", content: user }]
    })
  });

  if (!upstream.ok) {
    const t = await upstream.text();
    return Response.json({ error: `AI provider returned ${upstream.status}: ${t.slice(0, 300)}` }, { status: 502 });
  }
  return new Response(upstream.body, { headers: { "content-type": "text/event-stream", "cache-control": "no-cache" } });
};

export const config = { path: "/api/ai" };
